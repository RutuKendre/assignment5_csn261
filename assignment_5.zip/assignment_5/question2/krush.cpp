#include <cstdio>
#include<iostream>
#include <fstream>
#include <algorithm>
#include <iterator> 
#include <map> 
#include <cstdlib>
#include <cstring>
#include <sstream>
using namespace std;

// representation of undirected edge (u, v) having weight 'weight'
struct Edge {
    int u, v, weight;
};

// Union-find data structure
class UF    {
    int *id, cnt, *sz;
public:
	// Create an empty union find data structure with N isolated sets.
    UF(int N)   {
        cnt = N;
	id = new int[N];
	sz = new int[N];
        for(int i=0; i<N; i++)	{
            id[i] = i;
  	    sz[i] = 1;
	}
    }
    ~UF()	{
	delete [] id;
	delete [] sz;
    }
	// Return the id of component corresponding to object p.
    int find(int p)	{
        int root = p;
        while (root != id[root])
            root = id[root];
        while (p != root) {
            int newp = id[p];
            id[p] = root;
            p = newp;
        }
        return root;
    }
	// Replace sets containing x and y with their union.
    void merge(int x, int y)	{
        int i = find(x);
        int j = find(y);
        if (i == j) return;
		
		// make smaller root point to larger one
        if   (sz[i] < sz[j]) { id[i] = j; sz[j] += sz[i]; }
        else                 { id[j] = i; sz[i] += sz[j]; }
        cnt--;
    }
	// Are objects x and y in the same set?
    bool connected(int x, int y)    {
        return find(x) == find(y);
    }
	// Return the number of disjoint sets.
    int count() {
        return cnt;
    }
};

// comparator function for sorting edges in ascending order by weight
bool comp(Edge *a, Edge *b)   {
    return a->weight < b->weight;
}

int main()  {

    
    int V, E, i, N, u, v, cost;
    Edge **edges, **mst;
     
   
    ifstream myFileStream("l5_q2_input.csv");
     if(!myFileStream.is_open()){
    cout<<"file failed to open"<<endl;
    return 0;
       }
       string mysrc,mydest;
       int src[20],dest[20];
        int weig[20];
    
        string myString,line;
        int lines=0;
       while(getline(myFileStream,line))
       {
         
           stringstream ss(line);
           getline(ss,mysrc,',');
           src[lines]=(int)mysrc[0]-65;
           getline(ss,mydest,',');
           dest[lines]=(int)mydest[0]-65;
           getline(ss,myString,',');
           weig[lines]=stoi(myString);
           lines++;
        }


          int x=lines;
          
          myFileStream.close();


         
          E=x;
          edges = new Edge*[E];
    
     char u1,v1;
     int w1;

     map<char,int> map1;
     for(int i=0;i<26;i++)
     {
        map1.insert(pair<char,int>(i+65,i));
     }


    for(i=0; i<E; i++)  {   // Enter E undirected edges (u, v, weight)
        edges[i] = new Edge;
      
          edges[i]->u=src[i];
          edges[i]->v=dest[i];
          edges[i]->weight=dest[i];
    }

    
    sort(edges, edges + E, comp);
    UF uf(V);
    mst = new Edge*[V-1];
    for(N=i=cost=0; i<E && N<V-1; i++) {
        u = edges[i]->u; v = edges[i]->v;
        if(!uf.connected(u, v)) {
            uf.merge(u, v);
            mst[N++] = edges[i];
            cost += edges[i]->weight;
        }
    }
    
     map<int,char> map2;
     for(int i=0;i<V;i++)
     {
        map2.insert(pair<int,char>(i,i+65));
     }

   

    //printf("Total cost of MST : %d\n", cost);
    cout<<"Total cost of mst : "<<cost<<endl;
    //printf("Edges in MST :\n");
    cout<<"Edges in the mst are : "<<endl;
    for(i=0; i<N; i++)
        {
            cout<<map2[mst[i]->u]<<" ";
            cout<<map2[mst[i]->v]<<" ";
            cout<<mst[i]->weight<<endl;
        }
      
      ofstream myfile;
      myfile.open ("example.dot");
      myfile << "graph {\n";
      for(int i=0;i<N;i++)
      {
            //myfile<<map2[mst[i]->u]<<"--"<<map2[mst[i]->v]<<";"<<endl;
             myfile<<map2[mst[i]->u]<<"--"<<map2[mst[i]->v]<<"[label="<<mst[i]->weight<<"];"<<endl;
      }
       myfile<<"}"<<endl;
       myfile.close();
  
  

    return 0;
}
