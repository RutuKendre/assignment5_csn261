#include <iostream> 
#include <iterator> 
#include <map> 
  
using namespace std; 

  
void multiply(map<int,int> expression1,map<int,int> expression2,int degree1,int degree2)
{
      int maxdegreemulti=degree1*degree2;
    map<int, int> multiplication;
    for(int i=0;i<=degree1;i++)
    {
         for(int j=0;j<=degree2;j++)
         {
            int pow=i+j;
            multiplication[pow]=multiplication[pow]+expression1[i]*expression2[j];
            
         }

    }

    cout<<"Multiplication is"<<endl;
     map<int, int>::iterator itr3; 
    for(itr3=multiplication.begin();itr3!=multiplication.end();++itr3)
    {
        if(itr3->second!=0)
        {
            cout<<itr3->first<<" ";
            cout<<itr3->second<<endl;
        }
    }

}

void add(map<int,int> expression1,map<int,int> expression2,int degree1,int degree2)
{
     int maxdegreesum=degree1>=degree2?degree1:degree2;
        cout<<"Sum is"<<endl;
      map<int, int> sum; 
     for(int i=0;i<=maxdegreesum;i++)
     {
        int temp=expression1[i]+expression2[i];
        sum.insert(pair<int,int>(i,temp));
        if(temp!=0)
        {
            cout<<i<<" "<<temp<<endl;
        }

     } 
}

int main() 
{ 
  
    
    map<int, int> expression1; 

    cout<<"Enter number of terms in first expression"<<endl;
    int n1;
    cin>>n1;
    cout<<"Enter power and coefficients  "<<endl;
    int power;
    int coe;
    for(int i=0;i<n1;i++)
    {
       
         cin>>power;
         cin>>coe;
         expression1.insert(pair<int,int>(power,coe));
    }

     map<int, int> expression2; 
    cout<<"Enter number of terms in second expression"<<endl;
    int n2;
    cin>>n2;
    cout<<"Enter power and coefficients  "<<endl;
    for(int i=0;i<n2;i++)
    {
         cin>>power;
         cin>>coe;
        expression2.insert(pair<int,int>(power,coe));
    }

   //find degree
    map<int, int>::iterator itr1; 
    int degree1=0;
    for(itr1=expression1.begin();itr1!=expression1.end();++itr1)
    {
         int x=itr1->first;
         if(x>degree1)
         {
            degree1=x;
         }

    }
   

    map<int, int>::iterator itr2; 
    int degree2=0;
    for(itr2=expression2.begin();itr2!=expression2.end();++itr2)
    {
         int x=itr2->first;
         if(x>degree2)
         {
            degree2=x;
         }

    }



         int choice;
         cin>>choice;
    
    while(choice!=3)
    {
        cout<<"Enter 1 to add or 2 to multiply and 3 to exit"<<endl;
         cin>>choice;
        switch(choice)
    
    {

        case 1:
            add(expression1,expression2,degree1,degree2);
            break;

        case 2:
             multiply(expression1, expression2,degree1,degree2);  
             break; 
         case 3:
             exit(0);

    }

    }
    


    return 0; 
} 